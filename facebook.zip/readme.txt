Exercise number 3:

Names: 
Or Lerner, ID: 315430652
Tal Shmuel ID: 207472366

